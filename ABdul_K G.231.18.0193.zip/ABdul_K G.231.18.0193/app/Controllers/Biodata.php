<?php namespace App\Controllers;
 
use CodeIgniter\Controller;
use App\Models\Models_biodata;
 
class Biodata extends BaseController
{
    public function index(){
        $model = new Models_biodata();
        $data['bio'] = $model->getBiodata();
        echo view('view_biodata',$data);
    }

    public function tambahdata(){
     echo view('form_biodata');
    }

    public function simpandata(){
     $model = new Models_biodata();
        $data = array(
            'nik'  => $this->request->getPost('nik'),
            'nama' => $this->request->getPost('nama'),
            'hobi' => $this->request->getPost('hobi'),
            'alamat' => $this->request->getPost('alamat'),
        );
        $model->saveBiodata($data);
        return redirect()->to('/biodata');
    }

 public function edit($id){
        $model = new Models_biodata();
        $data['bio'] = $model->getBiodata($id)->getRow();
        echo view('form_biodata', $data);
    }

    public function update(){
        $model = new Models_biodata();
        $id = $this->request->getPost('nik');
  $data = array(
            'nik'  => $this->request->getPost('nik'),
            'nama' => $this->request->getPost('nama'),
            'hobi' => $this->request->getPost('hobi'),
            'alamat' => $this->request->getPost('alamat'),
        );
        $model->updateBiodata($data, $id);
        return redirect()->to('/biodata');
    }

    public function hapus($id){
        $model = new Models_biodata();
        $model->DelBiodata($id);
        return redirect()->to('/biodata');
    }
}