<?php namespace App\Models;
use CodeIgniter\Model;
 
class Models_biodata extends Model
{
    protected $table = 'biodata';
     
    public function getBiodata($id = false)
    {
        if($id === false){
            return $this->findAll();
        }else{
            return $this->getWhere(['nik' => $id]);
        }   
    }

    public function saveBiodata($data){
     $query = $this->db->table($this->table)->insert($data);
        return $query;
    }

    public function updateBiodata($data, $id){
        $query = $this->db->table($this->table)->update($data, array('nik' => $id));
        return $query;
    }

    public function DelBiodata($id){
        $query = $this->db->table($this->table)->delete(array('nik' => $id));
        return $query;
    } 
 }